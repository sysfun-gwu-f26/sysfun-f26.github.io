# mysh: a shell built in three milestones

Read `ASSIGNMENT.md` first (Section 1.1 explains the setup).

Quick start: install Docker Desktop and VS Code (with the *Dev Containers* extension), open this folder in
VS Code, choose **Reopen in Container**, then in the VS Code terminal:

```
make test1      # Week 1
make test2      # Week 2
make test3      # Week 3
make test       # lint + everything
```

Edit only the files in `src/`. The contract for each function is in `include/`.
